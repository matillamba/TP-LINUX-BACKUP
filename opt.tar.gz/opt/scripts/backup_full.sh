#!/bin/bash

#mostrar ayuda
if [[ "$1" == "-help" ]]; then
   echo "Uso: $0 ORIGEN DESTINO"
   echo "Ejemplo: $0 /var/log/backup_dir"
   exit 0 
fi

ORIGEN=$1
DESTINO=$2

#Validar parametros 
if [[ -z "$ORIGEN" || -z "$DESTINO" ]]; then
   echo "Error: faltan parametros. Usa -help para ayuda."
   exit 1 
fi

#Validar si existen los directorios
if [[ ! -d "$ORIGEN" ]]; then
   echo "Error: el origen no existe."
   exit  2
fi

if [[ ! -d "$DESTINO" ]]; then
   echo "Error: el destino no existe"
   exit 3 
fi

#Obtener fecha actual 
FECHA=$(date +%y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"

#Realizar backup
tar -czf "$ARCHIVO" "$ORIGEN" && echo "Backup creado en $ARCHIVO"
