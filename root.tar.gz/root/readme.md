#Trabajo Practico - Computacion Aplicada

## Participantes
Francisco Huber
Matias Julian Inostroza
Matias Joaquin Llamba
Joel Pauer

#Descripcion 

Este repositorio contiene la configuracion y scripts del trabajo practico para la materia computacion aplicada. incluye:

-configuracion de red 
-configuarion de apache
-base de datos
-script de backup
-cron jobs

